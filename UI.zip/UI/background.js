chrome.runtime.onInstalled.addListener(() => {
    (async () => {
      const capabilities = await chrome.aiOriginTrial.languageModel.capabilities();
      if (capabilities.available === 'after-download') {
        const session = await chrome.aiOriginTrial.languageModel.create({
          monitor(m) {
            m.addEventListener("downloadprogress", (e) => {
              console.log(`Downloaded ${e.loaded} of ${e.total} bytes.`);
            });
          },
        });
        // Use the session object to interact with the Prompt API
      } else if (capabilities.available === 'readily') {
        // Proceed if the model is already downloaded
      } else {
        console.error("Prompt API not available");
      }
    })();
  });